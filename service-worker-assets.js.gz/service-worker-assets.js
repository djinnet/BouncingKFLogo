self.assetsManifest = {
  "version": "Ng/dX8vZ",
  "assets": [
    {
      "hash": "sha256-9Z/+MBCfTH/eE5e5aYMGZ+WzaJLk8tl2MwD/AGVvifc=",
      "url": "_content/Blazor.Extensions.Canvas/blazor.extensions.canvas.js"
    },
    {
      "hash": "sha256-5stAuRwIRBg4LcjskicAGCtxMN4hVJmyJ3K+A+w8vxI=",
      "url": "_content/BouncingKFLogo/p5Interop.js"
    },
    {
      "hash": "sha256-2dpQzTbX8h/lAwyUlNEUwDR/AxwJIZ/oz0DhmLX2ct8=",
      "url": "_content/Interoply/interoplyEvents.js"
    },
    {
      "hash": "sha256-2AOrAB5tgoiK9wMMmwiE/pKPAtTjzgFudxSl6g4dt9s=",
      "url": "_framework/Blazor.Extensions.Canvas.45bjdsigtk.wasm"
    },
    {
      "hash": "sha256-ctyeKHsvFswpiKQJpTUUWdSrDGr4UNirukOrWYnwW78=",
      "url": "_framework/Blazor.Extensions.Canvas.JS.iokb7a5y98.wasm"
    },
    {
      "hash": "sha256-lc10/NBAFA7eVYiQSJGjL3leGurioTVjS+5tbqci83Y=",
      "url": "_framework/BouncingKFLogo.zi8p7569qr.wasm"
    },
    {
      "hash": "sha256-JFrc0XdxhCpcC/rNoZ4sGLtZTNiex5j561fsLJEixRY=",
      "url": "_framework/DeepCloner.01ggxdl51t.wasm"
    },
    {
      "hash": "sha256-mX/qwuezPXNo3BcMa7x0hIIN2Z2vU/8s2reEJmpVCic=",
      "url": "_framework/FluentAssertions.xekha9f8er.wasm"
    },
    {
      "hash": "sha256-rLGc9l6DgfFjBJ7rBoArXXx/jeojZ6hZmoAm0PL5p+E=",
      "url": "_framework/Interoply.wv3k5n8s6b.wasm"
    },
    {
      "hash": "sha256-edvymETuCK0skZaEc2Xq33FPuaTGcbT3B3Q1TMX75uw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.tj799dhpve.wasm"
    },
    {
      "hash": "sha256-jr4JfOF5IB9Qa7LVWyaX9Jnfs+OZVCjDquX+z2BFFX8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.6up78yjh1n.wasm"
    },
    {
      "hash": "sha256-oWwYN1b6kGrhKIjP3wLZpnxkpUkDFYTX1dtwqWTd2+0=",
      "url": "_framework/Microsoft.AspNetCore.Components.fsmw0mkk8t.wasm"
    },
    {
      "hash": "sha256-pOED2iNDgbaIZdNUqih81BZOhvMp17gA7UYEE6dbly8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.opwbk83jqu.wasm"
    },
    {
      "hash": "sha256-aUL1p8N7BVpff4zCDZ0GloDhldubhgfQ+pTN+yP+NL4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.hui4iqxkm7.wasm"
    },
    {
      "hash": "sha256-aGCPTRRX+LpoEC0kHuWtr4WOAl74G2p0HGSMadHDYYo=",
      "url": "_framework/Microsoft.Extensions.Configuration.oovwwqf5qf.wasm"
    },
    {
      "hash": "sha256-00B4izvl6aprRPV/OE1uX7+g8+VM/x89Y2NM4qbmonA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.fhityfkgn5.wasm"
    },
    {
      "hash": "sha256-szm/4Fl/8ThZEyTKn0DjT10dLkwAN75iOLpPaT9MziE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.zg5wmkbway.wasm"
    },
    {
      "hash": "sha256-7X7PJJKHxEdgZ6cv+FBqggxsi4RAQCqu7p8M/xtI434=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tw1xngcqhu.wasm"
    },
    {
      "hash": "sha256-9pgOS8ezhH7cPoYYDzmudhB+iMPHY/CSqQhb77PHTTk=",
      "url": "_framework/Microsoft.Extensions.Logging.eva8yn2t8j.wasm"
    },
    {
      "hash": "sha256-ECPOJnswyfl0xRUCR3StNwl4WbOlbBjTAyc7tp/ksbk=",
      "url": "_framework/Microsoft.Extensions.Options.0gp18t11e4.wasm"
    },
    {
      "hash": "sha256-4E9QgG80eMrFZtU2cQ3IdWiSy9K4odn43sch89M9Y9Y=",
      "url": "_framework/Microsoft.Extensions.Primitives.wgkaqcaqxl.wasm"
    },
    {
      "hash": "sha256-1391UuW9RnaY9v+RXWFFkaN+3zIkFWK6F/i2rkesTxo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.dnug9e66zg.wasm"
    },
    {
      "hash": "sha256-RnzeK09uvjLbb1tBlAEIRBdhADqNodaR0Cm1Llkso7o=",
      "url": "_framework/Microsoft.JSInterop.mlr4vw2ovb.wasm"
    },
    {
      "hash": "sha256-MSoMTDQXur0fEVr3RjoZTGsW/l816QXel4DrQ89ZOlg=",
      "url": "_framework/System.Collections.Concurrent.x83rtttxmb.wasm"
    },
    {
      "hash": "sha256-xd7Pq+ulBb1p7AqzHWeLciAgylz4b2mZNwb78jXu2ls=",
      "url": "_framework/System.Collections.Immutable.5oilleqjn9.wasm"
    },
    {
      "hash": "sha256-lN3dybxgW/YQ4IoufFxcWrOob9WKaCKjV/Mk8Lf0HsA=",
      "url": "_framework/System.Collections.NonGeneric.0xr9492unk.wasm"
    },
    {
      "hash": "sha256-8+fvTb1o0yRF6weWwnoR9m8M6j6lrxbIQ02wRY6RCtM=",
      "url": "_framework/System.Collections.Specialized.j450a1yj6o.wasm"
    },
    {
      "hash": "sha256-cKoauBxNUa82RhryfWt0FI+HlMLarHzY/IKRCgWQBn4=",
      "url": "_framework/System.Collections.gw6i740bra.wasm"
    },
    {
      "hash": "sha256-U3YxbkRMOAHudhrP298nIjaqOcf7nanFQkLbDyNkbUs=",
      "url": "_framework/System.ComponentModel.9x4za785zy.wasm"
    },
    {
      "hash": "sha256-Ro8BhaYd3XTxhMtpMvIH2gPkkiljjeWcp6ZPm9ttiBA=",
      "url": "_framework/System.ComponentModel.Primitives.ub1we99mom.wasm"
    },
    {
      "hash": "sha256-S/m36nZpWAHEW0gS6yJDGDu+R8Xpa8XTsLtNj8u1yQ0=",
      "url": "_framework/System.ComponentModel.TypeConverter.9ry7ndt76v.wasm"
    },
    {
      "hash": "sha256-J7MM/Iops2JRljQwRmPYSzTMow7Yyg4uTvdM7qwmxuw=",
      "url": "_framework/System.Configuration.ConfigurationManager.zxqrque6ns.wasm"
    },
    {
      "hash": "sha256-UY6M99pYB1FVWuUtdMP4VBoubK7+XwmMVLy5ymKPpjs=",
      "url": "_framework/System.Console.xgvsggvnx2.wasm"
    },
    {
      "hash": "sha256-7M/2ox3yfTSpSZb8iP8E88Hw/bDTEnELBBnSwDpTU3A=",
      "url": "_framework/System.Data.Common.8f7a0nnj0d.wasm"
    },
    {
      "hash": "sha256-1LYKxW8+DSYoAeaddtMNw64zAdyY3gafeB3f5xJF8Ss=",
      "url": "_framework/System.Diagnostics.Debug.sirqtr6f5j.wasm"
    },
    {
      "hash": "sha256-20MnV/nj/3JiyysUpagXdQ2XWsHPvhmacVcYcP0PUg0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.n1y6icprwn.wasm"
    },
    {
      "hash": "sha256-BGd388ETvwK2A5V+PYQOUzLIoebbD29OQQ2wqy7w5KI=",
      "url": "_framework/System.Diagnostics.StackTrace.swei1zvyip.wasm"
    },
    {
      "hash": "sha256-yvc4p/bOpGvHZrYLpsKLLmiBeXNqZ6x4v3m1GiWpuHk=",
      "url": "_framework/System.Diagnostics.TraceSource.6cgm46rgip.wasm"
    },
    {
      "hash": "sha256-hirPmtWL+sz8EBx8t2NG8s6S4wsjeKT9Vt8e2tN1qRc=",
      "url": "_framework/System.IO.FileSystem.2qd4j59s3q.wasm"
    },
    {
      "hash": "sha256-F7eq3vfkNdyf7BI0RJMCuDGtdhNgu4qn1GGWK5FvVz0=",
      "url": "_framework/System.IO.Pipelines.hqvxmp1tnr.wasm"
    },
    {
      "hash": "sha256-j3Z9IWZM6D/4cD1SCVaUYQS1stcwuKYCSsREEew7uc8=",
      "url": "_framework/System.Linq.Expressions.pu6njphsel.wasm"
    },
    {
      "hash": "sha256-lmgiK605bI1zO5lpdjqEwsSa5ljC9CQ0T9Bf6Bx4sLM=",
      "url": "_framework/System.Linq.m8i5p9oqu1.wasm"
    },
    {
      "hash": "sha256-ECLbc1+da5sOnq5gxaEbwUJwxnx1De5iRFuO+fPJUJ0=",
      "url": "_framework/System.Memory.0or0eqaudk.wasm"
    },
    {
      "hash": "sha256-Bk4OWbxL3ShAGizu2xd66knOz7DHj5eGVwixJ7ZAQNw=",
      "url": "_framework/System.Net.Http.a78el6mzgb.wasm"
    },
    {
      "hash": "sha256-QU1D5egLC//2CDZXCKgb0EwDl8kiRtxESkA9EXPAmlw=",
      "url": "_framework/System.Net.Primitives.n2molizd5d.wasm"
    },
    {
      "hash": "sha256-c3aMPjU0HwPmaF+04PNt/a+IajB3hJpFfP3gTAamk70=",
      "url": "_framework/System.Net.WebClient.d0w2z6ujql.wasm"
    },
    {
      "hash": "sha256-eL8i1rS0EqHMlaGiT37nOrxIvRqkPRSVoYee4KiMsDc=",
      "url": "_framework/System.ObjectModel.45tgh6c8vq.wasm"
    },
    {
      "hash": "sha256-1wvW7L0tenYamiir9eFWyr3Iob8Doyj2ctRL6gPjIRM=",
      "url": "_framework/System.Private.CoreLib.fet8ty0ra5.wasm"
    },
    {
      "hash": "sha256-uG4kYhNePoK2kUHIcMJwOaQxislPQOkFaJ2zKQ07Z/A=",
      "url": "_framework/System.Private.DataContractSerialization.s34ikume8x.wasm"
    },
    {
      "hash": "sha256-uIUgBEXgoJgALRHULHkKWWFUCcrwplhdcLsa2OOPh4g=",
      "url": "_framework/System.Private.Uri.sb1gzq3p23.wasm"
    },
    {
      "hash": "sha256-TQemwqqiB4ylNeqszT8u1qryrl2Gqx78uRmBHr0c1wU=",
      "url": "_framework/System.Private.Xml.Linq.zwpe6m6xbo.wasm"
    },
    {
      "hash": "sha256-DLIxhMjSLOIdznIcJI0KyisUrszTHzwjm6qOzXwlKR4=",
      "url": "_framework/System.Private.Xml.cou3g92kuv.wasm"
    },
    {
      "hash": "sha256-f4kCEJU42slnROJQsB6IV7514PGDAZRJm9ENip6MOEA=",
      "url": "_framework/System.Reflection.7u0lyc0auc.wasm"
    },
    {
      "hash": "sha256-k80EbLMXN/F3PLL6eqF6jHH7CQgHwv//p/MtUXTqHHQ=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.7f786cc3id.wasm"
    },
    {
      "hash": "sha256-1+CsVf/BsARNP6Om55z6e9V3cOkOSi6bZ6m/aRxoAEQ=",
      "url": "_framework/System.Reflection.Emit.Lightweight.3tsgrw7c4g.wasm"
    },
    {
      "hash": "sha256-g7FDSOO1IuhbB6Ryt4NCEF7bI5HQ3OA+WpXXNC6DpAs=",
      "url": "_framework/System.Reflection.Extensions.fpf49k53ni.wasm"
    },
    {
      "hash": "sha256-DvEvTWswJTlSZS9UhMfpOJ4jvdZeqI/5RzeaUIn8dmk=",
      "url": "_framework/System.Reflection.Primitives.q1h3srd7d7.wasm"
    },
    {
      "hash": "sha256-ygw3N6BiL57Glnm60Sukc/egokD/uja4w1U3ya3Xvdk=",
      "url": "_framework/System.Runtime.6kuqe6js20.wasm"
    },
    {
      "hash": "sha256-Ao8HSmh/1fGE6N7KQq+6bXcDMPpNzShsp6S/Kr1WmCU=",
      "url": "_framework/System.Runtime.Extensions.2390jkk9f4.wasm"
    },
    {
      "hash": "sha256-8v7jVijrzRlaTmvdds4+ZNyPL5DYfnYnzFYT2HtkqwM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.u9tzo6t7zm.wasm"
    },
    {
      "hash": "sha256-BTM9VQjV+nTSrYrUoz703d281qW4h5Gfr/Ljo4rd2nY=",
      "url": "_framework/System.Runtime.InteropServices.ji2hmwhl7f.wasm"
    },
    {
      "hash": "sha256-bDWBvj4Qs1XxByPLni+0cPULUAamGAZpCrQ1LwsW7ts=",
      "url": "_framework/System.Runtime.Serialization.Formatters.0xneawt7zt.wasm"
    },
    {
      "hash": "sha256-l0btBy/mrjgK8G0AqW0umBjqWKUaTv8AY275/ewvPdQ=",
      "url": "_framework/System.Runtime.Serialization.Primitives.78ncqv5rg1.wasm"
    },
    {
      "hash": "sha256-W3DqhVAzLl8uWyfF5d8m1Mzu7WMELID3MnbqwC+9AoI=",
      "url": "_framework/System.Runtime.Serialization.Xml.rkvqij13ms.wasm"
    },
    {
      "hash": "sha256-wcBAf0h7y3rB5RjU2Dq+T2Op09gT9FAGOR8XcdjechU=",
      "url": "_framework/System.Security.Cryptography.ProtectedData.z7mzo7prvf.wasm"
    },
    {
      "hash": "sha256-I/sEJ7hhKaRgoaYmiUqOQbKnrKwwok6gjuJeSvcyhWw=",
      "url": "_framework/System.Security.Cryptography.be2k6jcgqs.wasm"
    },
    {
      "hash": "sha256-oAvGjE7zOfELanuhXBazvipywX/fnbrfBmWPDH/R3bw=",
      "url": "_framework/System.Text.Encodings.Web.8qvkegu1ci.wasm"
    },
    {
      "hash": "sha256-HCkgMLCPB9Agnibol2M1EZCYfO6VLsAdu3QRjDIE+Dg=",
      "url": "_framework/System.Text.Json.s4n8edapif.wasm"
    },
    {
      "hash": "sha256-Ki3iPTxG47jjqdlJ3ze6ikluuVxAaT3bET8vSTKj6Ag=",
      "url": "_framework/System.Text.RegularExpressions.2xryxk06hf.wasm"
    },
    {
      "hash": "sha256-OZamhYeSBewaigm6XGkVt8U+LzjQusWFRKawu0FO7LM=",
      "url": "_framework/System.Threading.12jz3qk22s.wasm"
    },
    {
      "hash": "sha256-vKm32u+HCbVkLv23h0l0UIaX6nZqQRZ/w1Ya4zP2QWU=",
      "url": "_framework/System.Threading.Tasks.0facq44j7y.wasm"
    },
    {
      "hash": "sha256-UgDQgumqZj6p9gp1AxxwuF7FY0ittV25c4qrMW9q7XY=",
      "url": "_framework/System.Xml.Linq.62mgoxb9g2.wasm"
    },
    {
      "hash": "sha256-RFD6iKUyooJoUN6lAYIIGTcCrs3WGJoArv45WgJ2tOs=",
      "url": "_framework/System.Xml.ReaderWriter.wttdcz4dj4.wasm"
    },
    {
      "hash": "sha256-r8h1Wl2iyNNZhUQp6yKvTs19paTBbQxdwGwfRn5PDPY=",
      "url": "_framework/System.Xml.XDocument.zvrq1y50sm.wasm"
    },
    {
      "hash": "sha256-UFt9PJIfF9Cp44Nl11/hZSBC8R52F/hE1pL/Ctfkhfk=",
      "url": "_framework/System.Xml.XmlSerializer.4nnk82u3rq.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-SgThEZrhvgYKAtJT8oXbekISGIyo+s2ktYmt5NsJGxA=",
      "url": "_framework/Xeption.qole72j3du.wasm"
    },
    {
      "hash": "sha256-YpXSjxqdlPr67tGOF5jpFawQ2O8ONBxFVEwMVrjZv3M=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-p9eEzXhQIsI0a5bBJhfzW15iRafgplTxT8XrO5FiH9o=",
      "url": "_framework/dotnet.native.noby4tlk4d.js"
    },
    {
      "hash": "sha256-Po2dalLvTpf5jAS+jt0TzuBYybYiL1F6qAacZJ8UAdo=",
      "url": "_framework/dotnet.native.qe75a9vfqn.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-HxMKywlvmLvQYPCqjIRQgnQjZoBu+2fcKLZ2tCgfEUo=",
      "url": "_framework/netstandard.p2kpf752xg.wasm"
    },
    {
      "hash": "sha256-EGUXGLRNLFY4aaTjaFe2jAEN9KEXnJG6xfNjlAT58dc=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-eYejaH8PhGjS9y2J95n53JbYYt9LKqLX907h4OShhjk=",
      "url": "images/dvd_logo.png"
    },
    {
      "hash": "sha256-liA/oQckYfT+WITpX4reb7hYs59/N2MIu1bDgHegTT8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-vNvt9ymOZyPCJFEYXRCus0K7jFWxdwhiUbQe+JQ7e0Y=",
      "url": "manifest.webmanifest"
    }
  ]
};
